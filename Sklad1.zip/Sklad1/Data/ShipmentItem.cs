﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklad1.Data
{
    /// <summary>
    /// Модель позиции отгрузки
    /// </summary>
    [Table("shipment_items")]
    public class ShipmentItem
    {
        /// <summary>
        /// Идентификатор позиции
        /// </summary>
        [Column("id")]
        public Guid Id { get; set; }

        /// <summary>
        /// Идентификатор отгрузки
        /// </summary>
        [Column("shipment_id")]
        public Guid ShipmentId { get; set; }

        /// <summary>
        /// Идентификатор товара
        /// </summary>
        [Column("product_id")]
        public Guid ProductId { get; set; }

        /// <summary>
        /// Количество отгружаемого товара
        /// </summary>
        [Column("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Цена на момент отгрузки
        /// </summary>
        [Column("price_at_shipment")]
        public decimal PriceAtShipment { get; set; }

        /// <summary>
        /// Навигационные свойства
        /// </summary>
        public virtual Shipment Shipment { get; set; }
        public virtual Product Product { get; set; }
    }
}
