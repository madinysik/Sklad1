﻿using Sklad1.Data;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sklad1.Helpers
{
    /// <summary>
    /// Сервис для обработки отгрузок
    /// </summary>
    public static class ShipmentService
    {
        /// <summary>
        /// Выполняет отгрузку товаров
        /// </summary>
        public static bool ProcessShipment(string client, List<(string Article, int Quantity)> items)
        {
            Log.Information($"Отгрузка: клиент={client}, товаров={items.Count}");
            foreach (var item in items)
            {
                Log.Information($"Товар: {item.Article}, количество={item.Quantity}");
            }
            if (string.IsNullOrWhiteSpace(client))
            {
                Log.Warning("Отгрузка: не указан клиент");
                return false;
            }

            if (items == null || items.Count == 0)
            {
                Log.Warning("Отгрузка: список товаров пуст");
                return false;
            }

            using (var db = new Context())
            {
                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        var shipment = new Shipment
                        {
                            Id = Guid.NewGuid(),
                            UserId = CurrentUser.Id,
                            Client = client.Trim(),
                            Date = DateTime.UtcNow
                        };
                        db.Shipments.Add(shipment);
                        db.SaveChanges();

                        foreach (var item in items)
                        {
                            var product = db.Products.FirstOrDefault(p => p.Article == item.Article);
                            if (product == null)
                            {
                                Log.Warning($"Товар с артикулом {item.Article} не найден");
                                transaction.Rollback();
                                return false;
                            }

                            if (product.Quantity < item.Quantity)
                            {
                                Log.Warning($"Недостаточно товара {product.Name}. Доступно: {product.Quantity}, запрошено: {item.Quantity}");
                                transaction.Rollback();
                                return false;
                            }

                            if (item.Quantity <= 0)
                            {
                                Log.Warning($"Неверное количество для товара {product.Name}: {item.Quantity}");
                                transaction.Rollback();
                                return false;
                            }

                            var shipmentItem = new ShipmentItem
                            {
                                Id = Guid.NewGuid(),
                                ShipmentId = shipment.Id,
                                ProductId = product.Id,
                                Quantity = item.Quantity,
                                PriceAtShipment = product.PurchasePrice
                            };
                            db.ShipmentItems.Add(shipmentItem);

                            product.Quantity -= item.Quantity;
                        }

                        db.SaveChanges();
                        transaction.Commit();

                        Log.Information($"Отгрузка выполнена. Клиент: {client}, товаров: {items.Count}");
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Log.Error(ex, "Ошибка при выполнении отгрузки");
                        return false;
                    }
                }
            }
        }
    }
}
