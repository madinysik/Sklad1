﻿using Sklad1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklad1.Helpers
{
    /// <summary>
    /// Хранит данные текущего вошедшего пользователя
    /// </summary>
    public static class CurrentUser
    {
        public static Guid Id { get; set; }
        public static string FirstName { get; set; }
        public static string LastName { get; set; }
        public static string Email { get; set; }
        public static UserRole Role { get; set; }
    }
}
