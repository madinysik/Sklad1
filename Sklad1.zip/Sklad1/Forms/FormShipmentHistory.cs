﻿using Sklad1.Data;
using Serilog;
using System;
using System.Linq;
using System.Windows.Forms;

namespace Sklad1.Forms
{
    public partial class FormShipmentHistory : Form
    {
        public FormShipmentHistory()
        {
            InitializeComponent();
            LoadHistory();
        }

        /// <summary>
        /// Загружает историю отгрузок из базы данных
        /// </summary>
        private void LoadHistory()
        {
            try
            {
                using (var db = new Context())
                {
                    var history = db.ShipmentItems
                        .OrderByDescending(si => si.Shipment.Date)
                        .Select(si => new
                        {
                            si.Shipment.Date,
                            si.Shipment.Client,
                            ProductName = si.Product.Name,
                            si.Quantity,
                            si.PriceAtShipment,
                            CurrentStock = si.Product.Quantity
                        })
                        .ToList();

                    dataGridView1.DataSource = history;

                    // Настройка заголовков по ТЗ
                    dataGridView1.Columns["Client"].HeaderText = "Клиент";
                    dataGridView1.Columns["ProductName"].HeaderText = "Название товара";
                    dataGridView1.Columns["Quantity"].HeaderText = "Количество";
                    dataGridView1.Columns["PriceAtShipment"].HeaderText = "Цена";
                    dataGridView1.Columns["CurrentStock"].HeaderText = "Текущий остаток";
                    dataGridView1.Columns["Date"].HeaderText = "Дата";

                    // Форматирование даты
                    dataGridView1.Columns["Date"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";

                    Log.Information("Загружена история отгрузок");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Ошибка загрузки истории отгрузок");
                MessageBox.Show("Ошибка загрузки истории отгрузок!");
            }
        }
    }
}