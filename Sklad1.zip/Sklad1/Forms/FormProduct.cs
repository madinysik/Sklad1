﻿using Serilog;
using Sklad1.Data;
using Sklad1.Helpers;
using Sklad1.Properties;
using System.Text.RegularExpressions;

namespace Sklad1.Forms
{
    /// <summary>
    /// Форма создания нового товара
    /// </summary>
    public partial class FormProduct : Form
    {
        public FormProduct()
        {
            InitializeComponent();
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += btnCancel_Click;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private bool IsValidProductName(string text)
        {
            var trimmed = text.Trim();
            return Regex.IsMatch(trimmed, @"^[а-яА-ЯёЁa-zA-Z0-9\s\-]{2,100}$");
        }

        private bool IsValidArticle(string text)
        {
            var trimmed = text.Trim();
            return Regex.IsMatch(trimmed, @"^[0-9\-]{2,100}$");
        }
        private bool IsValidCategoryName(string text)
        {
            var trimmed = text.Trim();
            return Regex.IsMatch(trimmed, @"^[а-яА-ЯёЁa-zA-Z0-9\s\-]{2,100}$");
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            var article = txtArticle.Text.Trim();
            var name = txtName.Text.Trim();
            var categoryName = txtCategory.Text.Trim();
            var priceText = txtPurchasePrice.Text.Trim();

            if (string.IsNullOrWhiteSpace(article) ||
                string.IsNullOrWhiteSpace(name) ||
                string.IsNullOrWhiteSpace(categoryName) ||
                string.IsNullOrWhiteSpace(priceText))
            {
                MessageBox.Show(Resources.FillAllFields);
                return;
            }

            if (!IsValidProductName(name))
            {
                MessageBox.Show(Resources.InvalidProductName);
                return;
            }
            if (!IsValidArticle(article))
            {
                MessageBox.Show(Resources.InvalidArticle);
                return;
            }
            if (!IsValidCategoryName(categoryName))
            {
                MessageBox.Show(Resources.InvalidCategoryName);
                return;
            }

            if (!decimal.TryParse(priceText, out decimal price))
            {
                MessageBox.Show(Resources.InvalidPrice);
                return;
            }
            try
            {
                using (var bd = new Context())
                {
                    if (bd.Products.Any(p => p.Article == article))
                    {
                        MessageBox.Show(Resources.ArticleExists);
                        return;
                    }

                    if (bd.Products.Any(p => p.Name == name))
                    {
                        MessageBox.Show(Resources.ProductExists);
                        return;
                    }

                    var category = bd.Categories.FirstOrDefault(c => c.Name == categoryName);
                    if (category == null)
                    {
                        MessageBox.Show(Resources.CategoryNotFound);
                        return;
                    }

                    var product = new Product
                    {
                        Id = Guid.NewGuid(),
                        Article = article,
                        Name = name,
                        CategoryId = category.Id,
                        PurchasePrice = price
                    };

                    bd.Products.Add(product);
                    bd.SaveChanges();

                    MessageBox.Show(Resources.ProductCreate);
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Ошибка при создании товара");
                MessageBox.Show(Resources.ErrorSystem);
            }
        }
    }
}
