﻿using Sklad1.Data;
using Sklad1.Helpers;

namespace Sklad1.Forms
{
    public partial class FormShipment : Form
    {
        private List<ShipmentItemTemp> _items = new List<ShipmentItemTemp>();

        public FormShipment()
        {
            InitializeComponent();
            LoadProducts();
            btnAdd.Click += BtnAdd_Click;
            btnShip.Click += BtnShip_Click;
            btnCancel.Click += (s, e) => Close();
        }

        /// <summary>
        /// Загружает товары в выпадающий список (только те, что есть на складе)
        /// </summary>
        private void LoadProducts()
        {
            using (var db = new Context())
            {
                var products = db.Products
                    .Where(p => p.Quantity > 0)
                    .Select(p => new { p.Article, p.Name, p.Quantity, p.PurchasePrice })
                    .ToList();

                cmbProduct.DisplayMember = "Name";
                cmbProduct.ValueMember = "Article";
                cmbProduct.DataSource = products;
            }
        }

        /// <summary>
        /// Добавляет товар в таблицу отгрузки
        /// </summary>
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // Проверка выбора товара
            if (cmbProduct.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар!");
                return;
            }

            // Проверка количества
            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Введите корректное количество (целое число > 0)!");
                txtQuantity.Clear();
                txtQuantity.Focus();
                return;
            }

            dynamic selected = cmbProduct.SelectedItem;
            string article = selected.Article;
            string name = selected.Name;
            int available = selected.Quantity;

            // Проверка остатка
            if (quantity > available)
            {
                MessageBox.Show($"Недостаточно товара. Доступно: {available}");
                txtQuantity.Clear();
                txtQuantity.Focus();
                return;
            }

            // Проверяем, не добавлен ли уже этот товар
            var existing = _items.FirstOrDefault(i => i.Article == article);
            if (existing != null)
            {
                if (existing.Quantity + quantity > available)
                {
                    MessageBox.Show($"Недостаточно товара. Всего в списке: {existing.Quantity + quantity}, доступно: {available}");
                    return;
                }
                existing.Quantity += quantity;
            }
            else
            {
                _items.Add(new ShipmentItemTemp
                {
                    Article = article,
                    Name = name,
                    Quantity = quantity,
                    Price = selected.PurchasePrice
                });
            }

            UpdateGrid();
            txtQuantity.Clear();
            txtQuantity.Focus();
        }

        /// <summary>
        /// Обновляет таблицу на форме
        /// </summary>
        private void UpdateGrid()
        {
            dgvItems.DataSource = null;
            dgvItems.DataSource = _items;

            // Настройка заголовков
            dgvItems.Columns["Article"].HeaderText = "Артикул";
            dgvItems.Columns["Name"].HeaderText = "Название";
            dgvItems.Columns["Quantity"].HeaderText = "Количество";
            dgvItems.Columns["Price"].HeaderText = "Цена";

            // Включаем кнопку отгрузки только если есть товары
            btnShip.Enabled = _items.Count > 0;
        }

        /// <summary>
        /// Совершает отгрузку
        /// </summary>
        private void BtnShip_Click(object sender, EventArgs e)
        {
            // Проверка получателя
            if (string.IsNullOrWhiteSpace(txtClient.Text))
            {
                MessageBox.Show("Укажите получателя!");
                txtClient.Focus();
                return;
            }

            // Проверка, есть ли товары
            if (_items.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы один товар!");
                return;
            }

            var itemsForShipment = _items.Select(i => (i.Article, i.Quantity)).ToList();

            bool success = ShipmentService.ProcessShipment(txtClient.Text.Trim(), itemsForShipment);

            if (success)
            {
                MessageBox.Show("Отгрузка выполнена успешно!");
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show("Ошибка при выполнении отгрузки! Проверьте остатки товаров.");
            }
        }
    }

    /// <summary>
    /// Временная модель для отображения в таблице
    /// </summary>
    public class ShipmentItemTemp
    {
        public string Article { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
